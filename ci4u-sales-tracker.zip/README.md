# CI4U Sales Tracker

This repository is a centralized resource for tracking outreach, performance, and client interactions of CI4U's sales representatives. It includes template files for lead tracking, follow-ups, and performance reporting.

---

## 📊 Access the Google Sheet Tracker

[![Google Sheet](https://img.shields.io/badge/Google%20Sheet-Click%20to%20View-brightgreen?logo=google-sheets)](https://docs.google.com/spreadsheets/d/10qqIcAvqnUR3qDHmYpZmBUnk5FIx2KVnhgZqj-Fo3dk/edit?usp=sharing)

---

## 📁 Included Files

- `sales-tracker-template.csv`: A CSV template with all necessary columns to begin tracking leads and performance.
